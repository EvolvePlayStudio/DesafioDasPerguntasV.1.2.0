# Próximos passos
"""
- Ver como tratar as perguntas inativas e deletadas na view que mostra a quantidade de perguntas criadas
- Impedir registro múltiplo na tela de registro (apertando repetidamente o botão de registrar) e exibir mensagem mostrando que o usuário deve aguardar
- Colocar para pegar dicas e perguntas restantes quando iniciar um quiz ou entrar na tela home e não no login
- Analisar se é possível colocar para finalizar o quiz quando apertar na seta de voltar na tela de quiz
- Colocar para logar e registrar apertando enter
- Impementar o método para registrar histórico de versões de perguntas autmaticamente a subir a versão no SQL
- IMPEDIR MUDANÇA DE PERGUNTA ATUALIZANDO A PÁGINA OU RETORNANDO PARA A PÁGINA HOME
- RESERVAR O NOME EVOLVEPLAY STUDIO PARA QUE OS USUÁRIOS NÃO POSSAM UTILIZAR ESTE NOME E NEM NENHUM PARECIDO COM ESTE
- Criar um esquema de relatar problema em uma questão
- Criar o arquivo robots.txt
- Impedir que se mude o modo de jogo ou o tipo de pergunta enquanto um quiz está sendo preparado
- Criar a tela que mostra a pontuação em cada tema do usuário
- Criar uma tabela de registro de erros para enviar qualquer erro que ocorra quando o usuário usa o site
- ANALISAR ERRO QUANDO NÃO É POSSÍVEL SE CONECTAR COM O SERVIDOR AO ENVIAR UMA RESPOSTA PARA PERGUNTA OBJETIVA (FICA PERMITINDO MODIFICAR ALTERNATIVA MESMO DEPOIS DE INDICAR SE A RESPOSTA FOI CORRETA)
- CRIAR FUNÇÃO NO SQL PARA QUANDO UMA PERGUNTA MUDAR DE TEMA, TODAS AS PERGUNTAS FAVORITADAS PELOS USUÁRIOS NA TABELA FAVORITOS_USUARIOS TAMBÉM MUDAREM DE TEMA
- Ao clicar em finalizar quiz na revisão, deve-se retornar para o tema e tipo de pergunta selecionado anteriormente
- Salvar no localStorage as preferências do usuário para os subtemas (salvar o último tema e tipo de pergunta utilizado também) e usar o filtro quando a tela for carregada; também pode-se talvez mostrar quando tiver subtemas novos com um "new"
- Colocar para as perguntas que aparecem na tela de pesquisa ficarem na ordem cronológica de acordo com a data em que o usuário respondeu
- Substituir as perguntas deletadas objetivas com ids 153, 154 e 157
- Investigar por que a imagem de pesquisa não carrega na tela de pesquisa
- Analisar o que fazer com a possibilidade de o usuário ir direto para um página específica (ex: home) sem fazer login
- Colocar o ícone de dica mais para a direita no modo revisão
- Criar um limite para altura da tela de login e home para dispositivo Android (o footer fica muito lá embaixo)
- PEGAR A PONTUAÇÃO DO USUÁRIO NOS TEMAS AO INCIAR UM QUIZ PARA NÃO OCORRER PROBLEMA QUANDO NOVOS TEMAS FOREM ADICIONADOS
- VER O PROBLEMA DE PERGUNTAS REPETIDAS QUANDO COLOCA PARA RECARREGAR A PÁGINA NA TELA DE QUIZ
- Talvez seja bom colocar um sessão de dúvidas na tela de login para caso o usuário nao consiga se registrar ou logar. Talvez ali seja mostrado também mais informações sobre o app, com imagens das outras telas e tudo mais
- INVESTIGAR PROBLEMA DE O MODO VISITANTE FICAR UNDEFINIED QUANDO SE RETOMA DE UMA SESSÃO DO DIA ANTEROR EM VEZ DE FAZER LOGIN NOVAMENTE
- COLOCAR A DATA DE REGISTRO NA TABELA USUARIOS_REGISTRADOS NO FUSO DE SÃO PAULO E GARANTIR QUE AO ANALISAR O TOKEN DE CONFIRMAÇÃO, QUE ESTÁ VENDO PELO FUSO DE SÃO PAULO TAMBÉM
- RESOLVER O PROBLEMA DE PODER MUDAR ALTERNATIVA DEPOIS DE JÁ TER ENVIADO A RESPOSTA
- CRIAR REGRA PARA A PROPORÇÃO DE DIFICULDADE DAS PERGUNTAS QUE SÃO SELECIONADAS EM CADA RANKING (EX: NO ESTUDANTE, O MÁXIMO DE DIFÍCEIS QUE PODERÃO SER PEGADAS DA BASE DE DADOS SÃO 20%; NO LENDA, O MÁXIMO DE NÍVEL MÉDIO PEGADA SÃO 50%; ASSIM A DIFICULDADE DA PERGUNTA FICA DE ACORDO COM O RANKING DO USUÁRIO). TAMBÉM PODE-SE ORGANIZAR AS PERGUNTAS DE FORMA QUE NÃO VENHAM SÓ DE 1 NÍVEL DE DIFICULDADE VÁRIAS VEZES CONSECUTIVAMENTE DURANTE O QUIZ
- IDS DE PERGUNTAS DISCURSIVAS QUE IRÃO PARA AS OBJETIVAS POR PROVAVELMENTE SEREM MUITO DIFÍCEIS (POR ENQUANTO FICARÃO INATIVAS OU DELETADAS): 364, 397, 498, 505
"""
# Ideias de longo prazo
"""
- Investigar porque em alguns smartphones a cor do texto nas alternativas fica azul
- Fazer com que as páginas de política de privacidade, termos de uso e sobre o app fiquem com a mesma URL tanto para os usuários que acessam pela página de login quanto para os que acessam pela página home, mas o botão para retornar à home deve ficar diferente para os que acessam pela página de login
- Aumentar um pouco a altura da caixa de texto nas perguntas discursivas para que o acento fique mais visível
- Ajustar os tamanhos de letras e widgets para dispositivos smartphones nas outras telas além da de quiz
- Analisar os textos de rankings desalinhados com a barra de progresso e os de alternativas desalinhados com as letras de alternativas em dispositivo Android
- Remover o código desnecessário no CSS da página de pesquisa avançada (copiei e colei da outra página de pesquisa)
- Adicionar botão de voltar na tela de doações
- Analisar o que acontece com o session se uma pessoa abrir duas abas em contas diferentes
- Adicionar botão de retornar na tela de doações
- Resolver o problema de a palavra no enunciado ser colocada na primeira fileira e depois que se vê que não dá para colocá-la lá, o enunciado empurra para a segunda fileira
- Tratar erros na função de registrar ao tentar conexão com a base de dados
- Pode-se colocar para os usuários votarem para adicionar novos subtemas para as perguntas (as iniciais só vão ter os principais subtemas)
- Colocar a mensagem de senha redefinida na mesma tela onde se redefine
- No registro deve-se impedir copy and paste nas senhas e verificar o tempo que o usuário demorou para digitar a senha para reforçar o CAPTCHA
- Mostrar para o destinatário ignorar mensagem no e-mail caso o destinatário enviado seja errado na mensagem de confirmação de e-mail e recuperação de senha
- Permitir salvar perguntas nos favoritos para ajudar a fixar o conhecimento ou criar um método que identifica as perguntas que o usuário erra com mais frequência para usar no modo Revisão
- Garantir que os urls das páginas do site utilizem o protocolo https
- Disponibilizar opção de exclusão de conta
- Colocar o bloqueio futuramente por múltiplas tentativas fracassadas no formulário de registro, não só no CAPTCHA
- Depois ver se não é possível aumentar a segurança no CAPTCHA colocando números aleatórios de imagens que devem ser selecionadas
- Criar um limite máximo para o registro do tempo gasto nas perguntas (ex: 10 minutos)
- Ver a questão da quebra de linha deixando espaços em excesso no final da linha
- Criar estatísticas para o usuário ver o progresso na pontuação ao longo do tempo
- Termos para pôr em itálico no PostGreeSQL: vaccinus na nota da pergunta de ID 8
- Fazer indexação por tipo_pergunta na tabela respostas_usuarios
"""
# Coisas importantes para não esquecer
"""
- CASO VÁ REUTILIZAR O ID DE UM PERGUNTA DELETADA, DEVE-SE APAGAR TODOS OS FEEDBACKS E RESPOSTAS DE USUÁRIOS ENVIADAS PARA PERGUNTAS QUE TINHAM AQUELE ID
- Mudar os temas válidos quando for adicionar novos temas na tabela SQL
- Quando for criar as perguntas objetivas o tipo_pergunta deverá ser setado na função de enviar feedbacks
"""
# Ideias para a tela de Resultado
"""
- Deve-se mostrar tempo médio em cada nível de perguntas, quantas foram respondidas em cada nível e no total e quantos pontos foram ganhos ou perdidos em cada nível e no total
- Tudo isto talvez seja agrupado em uma tabela
- Colocar para refazer as perguntas que errou
"""
# Códigos importantes
"""
# Mostrar tudo que está no localStorage
for (let i = 0; i < localStorage.length; i++) {
  const chave = localStorage.key(i);
  const valor = localStorage.getItem(chave);
  console.log(`${chave}:`, valor);
}
# Apagar algo do localStorage
localStorage.removeItem("item_para_apagar");

# Código para pegar item aleatório em lista
function choice(array) {
  const indice = Math.floor(Math.random() * array.length);
  return array[indice];
}
# SQL, código para pegar horário de São Paulo
date_trunc('second', CURRENT_TIMESTAMP AT TIME ZONE 'America/Sao_Paulo')

# Mostrar e remover jobs
for job in scheduler.get_jobs():
    print(job.id, job.next_run_time)
scheduler.remove_all_jobs()

# Criar arquiv requirements.txt
pip freeze > requirements.txt
"""
# Ideias recomendadas pela IA
"""
⚙️ Próximos passos recomendados (práticos e visionários):

1. Monitore logs com consistência
Use o painel da Render para acompanhar logs de erro e conexão. Assim, antecipa falhas antes que impactem usuários.


2. Implemente reconexão automática (caso use pooling manual)
Em ambiente de produção, conexões com banco podem cair. Use ferramentas como SQLAlchemy com pool_pre_ping=True ou psycopg2 com retry.


3. Garanta escalabilidade futura
Quando escalar, considere separar camadas: frontend, API e banco — todos integrados por URLs internos. Isso evita gargalos.


4. Backup regular do banco de dados
Configure políticas de backup automáticas via Render, e eventualmente salve dumps localmente para redundância.


5. Evite conexão local durante desenvolvimento
Sempre que possível, simule produção em ambiente Docker com o mesmo esquema de banco e rede (ou use o banco da Render direto no ambiente dev).
"""
# Outras opções para o símbolo de pergunta pulada
"""
// Opção 2 – quadrado arredondado amarelo com interrogação branca (movido 2px para baixo)
const svg2 = `<svg xmlns="http://www.w3.org/2000/svg" width="28" height="28" viewBox="0 0 24 24" aria-hidden="true" style="vertical-align: middle;">
  <g transform="translate(0,0.2)">
    <rect x="2" y="2" width="20" height="20" rx="5" fill="#FFD700"/>
    <text x="50%" y="50%" text-anchor="middle" dominant-baseline="central"
          font-family="Segoe UI Emoji,Segoe UI Symbol,Arial" font-size="12" font-weight="700" fill="black">?</text>
  </g>
</svg>`;

// Opção 3 – círculo contornado amarelo com interrogação no centro (mais sutil, movido 2px para baixo)
const svg3 = `<svg xmlns="http://www.w3.org/2000/svg" width="28" height="28" viewBox="0 0 24 24" aria-hidden="true" style="vertical-align: middle;">
  <g transform="translate(0,0.2)">
    <circle cx="12" cy="12" r="10" fill="none" stroke="#FFD700" stroke-width="2"/>
    <text x="50%" y="50%" text-anchor="middle" dominant-baseline="central"
          font-family="Segoe UI Emoji,Segoe UI Symbol,Arial" font-size="12" font-weight="700" fill="#FFD700">?</text>
  </g>
</svg>`;
"""
# Opções de fontes
"""
# Usada atualmente em home
@import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;600;700&display=swap');
font-family: "Inter", system-ui, -apple-system, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif;

# Usada atualmente no enunciado da pergunta
@import url('https://fonts.googleapis.com/css2?family=Roboto:wght@400;700&family=Noto+Serif&display=swap');
font-family: 'Noto Serif', 'Roboto', serif, sans-serif;

@import url('https://fonts.googleapis.com/css2?family=Fira+Math&display=swap');
font-family: 'Fira Math', serif;

@import url('https://fonts.googleapis.com/css2?family=Merriweather:wght@400;700;900&display=swap');
font-family: 'Merriweather', serif;

@import url('https://fonts.googleapis.com/css2?family=Roboto+Flex:opsz,wght@12..144,100..1000&display=swap')
font-family: 'Roboto Flex', sans-serif;
"""
# Emoticons
"""
➕, 🔝, 📝, ✍️, 🧑, 👤, 📋, 🪪, 🌟, 🧠, 📊, 🔍, ⭐, ✨ , 🎯 , ✅, 🎉, 💯, 🏆, 💰,
🆓, ❔, ⁉️, 🤔, 🎁, ❓, 💡, ⚡, 🚀, 📚, 🔥, 🔒, ⚙️, 🛠️, ​📩, ​📧, ​📨, ​✉️, 📬, 🔹, ✏️,
🌱, 🧩, 🎓, 🧙‍♂️, 🌟,ℹ️, 📖, ❕, 🤝, ​☕, 🎨, 🎭, 🪐, 🔭, 🧬, 🌿, ⚽, 🗿, 🦉, ⚛️, 🌍,
🗺️, 🏛️, 📜, 📺, 📱, 🎵, 🎸, 🧪, ⚗️,🎲
"""

# Perguntas que irão em Variedades
"""
('Variedades', '{Biologia, Química, Geografia}',
 'Qual é o principal reservatório de fósforo no ciclo biogeoquímico?',
 'Rochas sedimentares',
 'Matéria orgânica em decomposição',
 'Oceanos',
 'Solos',
 'A',
 'Nota: O fósforo é liberado lentamente por intemperismo de rochas sedimentares',
 'Difícil'),
"""

# Subtemas secundários para o Desafio das Perguntas

# Biologia
"""
. Anatomia
. Fisiologia
. Histologia
. Imunologia
. Reprodução
"""

# Esportes
"""
. Atletas
. Competições
. Estilos
. Equipamentos
. Equipes
. Modalidades
. Recordes
. Regras
"""

# História
"""
. Diplomacia
. História do Brasil
. História Geral
"""

# Química
"""
. Aplicações
. Composição
. Compostos
. Elementos
. Estados da Matéria
. Estequiometria
. Gases
. Ligações Químicas
. Misturas 
. Nomenclatura 
. Propriedades
. Reações
. Substâncias
. Tabela Períodica
. Termoquímica
"""

# Tecnologia
"""
. Automóveis
. Aviões
. Dispositivos Móveis
"""

"""Vignettes ads do monetag
  <script>(function(s){s.dataset.zone='10617484',s.src='https://gizokraijaw.net/vignette.min.js'})([document.documentElement, document.body].filter(Boolean).pop().appendChild(document.createElement('script')))</script>

  <script>(function(s){s.dataset.zone='10617483',s.src='https://gizokraijaw.net/vignette.min.js'})([document.documentElement, document.body].filter(Boolean).pop().appendChild(document.createElement('script')))</script>

  <script>(function(s){s.dataset.zone='10617482',s.src='https://gizokraijaw.net/vignette.min.js'})([document.documentElement, document.body].filter(Boolean).pop().appendChild(document.createElement('script')))</script>
"""