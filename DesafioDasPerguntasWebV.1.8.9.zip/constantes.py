import tratamento_erros
from kivy.core.window import Window
from kivy.core.audio import SoundLoader
from kivy.uix.screenmanager import ScreenManager, NoTransition
from PIL import ImageFont
import os

# Telas e variáveis nulas
sm = ScreenManager(transition=NoTransition())
tela_menu = tela_notificacoes = tela_opcoes = tela_pesquisa = tela_informacoes = tela_premium = tela_intermediaria = tela_quiz = modo_de_jogo = tema_escolhido = dificuldade_pergunta = caminho_arquivo = ranking_atual = None

# Outras variáveis (o novo folga textos precisa ser copiado para o Desafios de Geografia)
folga_textos, versao_app, q_estrelas_marcadas, max_perguntas_por_nivel, notificacoes_lidas = 0.07 * Window.width, '1.1.3', 0, 30, False

# Listas
tot_temas, tot_niveis, tot_letras, tempos_animacoes, q_perguntas_filtradas, rankings, versoes_ordenadas = ['Artes', 'Astronomia', 'Biologia', 'Esportes', 'Filosofia', 'Geografia', 'História', 'Jogos', 'Mídia', 'Música', 'Química', 'Tecnologia'], ['Fácil', 'Médio', 'Difícil'], ['A', 'B', 'C', 'D'], [0.062, 0.047, 0.032], [0, 0, 0], ['Iniciante', 'Aprendiz', 'Estudante', 'Sábio', 'Lenda'], []

# Dicionários
dados_tema, dados_usuario, preferencias_usuario, chaves_estatisticas, dominios_email_permitidos, notificacoes, ids_perguntas_embaralhados, ids_perguntas_erradas, perguntas_filtradas, estatisticas_de_acertos = {}, {}, {}, [("acertos_no_facil", "respostas_no_facil"), ("acertos_no_medio", "respostas_no_medio"), ("acertos_no_dificil", "respostas_no_dificil")], {"gmail.com", "outlook.com", "hotmail.com", "yahoo.com", "protonmail.com", "tutanota.com", "zoho.com"}, {}, {}, {}, {}, {}

# Áudios
som_tecla_digitada = SoundLoader.load('Audios/TeclaDigitada.wav')
som_checkbox = SoundLoader.load('Audios/Checkbox.wav')
som_botao_pressionado = SoundLoader.load('Audios/BotaoPressionado.wav')
som_erro = SoundLoader.load('Audios/Erro.wav')

# Imagens
img_seta_esq_retorno, check_normal, check_down, radio_normal, radio_down, estrela_desmarcada, estrela_marcada, meia_estrela_marcada = 'OutrasImagens/SetaEsquerdaRetorno.png', 'OutrasImagens/square_checkbox_normal.png', 'OutrasImagens/square_checkbox_down.png', 'OutrasImagens/radio_checkbox_normal.png', 'OutrasImagens/radio_checkbox_down.png', 'OutrasImagens/EstrelaDesmarcada.png', 'OutrasImagens/EstrelaMarcada.png', 'OutrasImagens/MeiaEstrelaMarcada.png'

# Cores
verde, vermelho, amarelo, azul = ('#00FF00', (0, 1, 0, 1)), ('#FF0000', (1, 0, 0, 1)), ('#FFFF00', (1, 1, 0, 1)), ('#0000FF', (0, 0, 1, 1))
cores = [verde, amarelo, vermelho, azul]
cor_bg_botao = (0.9, 0.9, 0.9 * 0.9, 1)
cor_fg_botao = (1, 1, 1, 1)
cor_contorno_botao = (0, 0, 0, 1)
"""cor_fundo_tela = (0.12, 0.12, 0.04, 1)"""
cor_fundo_tela = (0.12, 0.12, 0.08, 1)
"""cor_fundo_btn_menu = (0.50, 0.50, 0.20, 1)"""
cor_fundo_btn_menu = (0.50, 0.50, 0.28, 1)

# Espessuras das linhas e contornos das letras
espessura_contorno = 0.0045 * Window.height

# Tamanhos das fontes
tamanho_fonte_textos = round(1.25 * min(0.025 * Window.height, 0.045 * Window.width))
tamanho_fonte_textos_menores = tamanho_fonte_textos - 1
tamanho_fonte_btn_menu = tamanho_fonte_textos - 2 # Também usado para mostrar versão do app
opcoes_tamanho_letra = [tamanho_fonte_textos - 1, tamanho_fonte_textos, tamanho_fonte_textos + 1]
font_textos = ImageFont.truetype('fonts/Roboto-Regular.ttf', round(tamanho_fonte_textos))
font_textos_menores = ImageFont.truetype('fonts/Roboto-Regular.ttf', round(tamanho_fonte_textos_menores))
ajuste_widgets_direita = 0.4 * tamanho_fonte_textos
comprimento_letra = font_textos.getmask('D)').getbbox()[2]

# Tamanhos dos botões e labels
altura_botao_menor = 2.7 * tamanho_fonte_textos # Altura usada no botão de confirmar e finalizar o quiz
tamanho_btn_escolha_tema = [0.41 * Window.width, 0.41 * Window.width * 1.082]
espaco_disponivel_hori_btns = Window.width - 2 * tamanho_btn_escolha_tema[0]
tamanho_btn_retornar = [0.12 * Window.width, 0.12 * Window.width] # Necessário investigar se há utilidade real disto
tamanho_img_checkbox = [1.57 * tamanho_fonte_textos, 1.57 * tamanho_fonte_textos]
tamanho_img_estrela = [1.4 * tamanho_fonte_textos, 1.4 * tamanho_fonte_textos]
espaco_disponivel_hori_estrelas = Window.width - 5 * tamanho_img_estrela[0]
tamanho_lbl_padrao = [2 * Window.width, 0.5 * Window.height]
dist_check_textos = 0.83 * tamanho_fonte_textos # distância entre a imagem de um check e o texto que fica ao lado
espacamento_widgets_modal_view = 2 * tamanho_fonte_textos
dist_vert_widgets = 3.2 * tamanho_fonte_textos

# Posições dos botões e tamanho dos layouts
x_btn_esquerdo = 0.027 * Window.width + espessura_contorno
ajuste_textos = 0.85 * tamanho_fonte_textos # Será removido futuramente
"""max_ajuste_enunciado = 1.05 * x_btn_esquerdo"""
max_ajuste_enunciado = 0.7 * x_btn_esquerdo
"""max_ajuste_enunciado = 1.55 * x_btn_esquerdo"""
"""max_ajuste_alternativas = 1.2 * x_btn_esquerdo"""
max_ajuste_alternativas = 1.14 * x_btn_esquerdo
altura_layout_menor = altura_botao_menor + 2 * espessura_contorno + 2 * x_btn_esquerdo
altura_layout_premium = 20 * tamanho_fonte_textos
altura_sv = Window.height - 2 * altura_layout_menor
y_btn_baixo = 0.5 * altura_layout_menor - altura_botao_menor / 2
